/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Pessoa;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bia
 */
public class PessoaDAO {
    private Conexao conexao;
    private Connection conn;
    
    public PessoaDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();    
    }
        public void inserir(Pessoa pessoa){
        String sql = "INSERT INTO pessoa(nome, email, cpf) VALUES "
                + "(?, ?, ?)";
        try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, pessoa.getNome());
        stmt.setString(2, pessoa.getEmail());
        stmt.setInt(3, pessoa.getCpf());
        stmt.execute();
    }
        catch(Exception e){
            System.out.println("Erro ao inserir cadastro: " + e.getMessage());
        }
        }
        public void editar(Pessoa pessoa){
        String sql = "UPDATE pessoa SET nome=?, email=?, cpf=? WHERE id_pessoa=?";
        try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, pessoa.getNome());
        stmt.setString(2, pessoa.getEmail());
        stmt.setInt(3, pessoa.getCpf());
        stmt.execute();    
        } catch (Exception e){
            System.out.println("Erro ao editar cadastro: " + e.getMessage());
        }
    }
    
    public void excluir(int id_pessoa){
        String sql = "DELETE FROM pessoa WHERE id_pessoa=?";
        try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setInt(1, id_pessoa);
        stmt.execute();    
        } catch (Exception e){
            System.out.println("Erro ao excluir cadastro: " + e.getMessage());
        }
    }
    
        public Pessoa getPessoa(int id_pessoa){
        String sql = "SELECT * FROM pessoa WHERE id_pessoa = ?";
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,
            ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id_pessoa);
            ResultSet rs = stmt.executeQuery();
            Pessoa pessoa = new Pessoa();
            rs.first();
            pessoa.setId_pessoa(id_pessoa);
            pessoa.setNome(rs.getString("nome"));
            pessoa.setEmail(rs.getString("email"));
            pessoa.setCpf(rs.getInt("cpf"));
            return pessoa;
        } catch(Exception e){
            System.out.println(e.getMessage());
            return null;
            
        }
    }
      
        public List<Pessoa> getPessoa(String email){
        String sql = "SELECT * FROM pessoa WHERE email LIKE?";
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, "%" + email + "%");
            ResultSet rs = stmt.executeQuery();
            List<Pessoa> listaPessoa =new ArrayList<>();
            while(rs.next()){
                Pessoa pessoa = new Pessoa();
                pessoa.setNome(rs.getString("nome"));
                pessoa.setEmail(rs.getString("email"));
                pessoa.setCpf(rs.getInt("cpf"));
                listaPessoa.add(pessoa);
            }
            return listaPessoa;
        }catch(Exception e){
            System.out.println(e.getMessage());
            return null;
        }
    }
        }
     
        

