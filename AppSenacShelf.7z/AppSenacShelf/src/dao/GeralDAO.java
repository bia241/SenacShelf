/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Geral;
import beans.Sessoes;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bia
 */
public class GeralDAO {
    private Conexao conexao;
    private Connection conn;
    
    public GeralDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();    
    }
    
    public void inserir(Geral geral){
        String sql = "INSERT INTO geral(titulo, autor, categoriaid) VALUES "
                + "(?, ?, ?)";
        try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, geral.getTitulo());
        stmt.setString(2, geral.getAutor());
        stmt.setInt(3, geral.getCategoriaid());
        stmt.execute();
    }
        catch(Exception e){
            System.out.println("Erro ao inserir livro: " + e.getMessage());
        }
    }
    
    public void editar(Geral geral){
        String sql = "UPDATE geral SET titulo=?, autor=?, categoriaid=? WHERE id=?";
        try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, geral.getTitulo());
        stmt.setString(2, geral.getAutor());
        stmt.setInt(3, geral.getCategoriaid());
        stmt.setInt(4, geral.getId());
        stmt.execute();    
        } catch (Exception e){
            System.out.println("Erro ao editar livro: " + e.getMessage());
        }
    }
    
    public void excluir(int id){
        String sql = "DELETE FROM geral WHERE id=?";
        try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setInt(1, id);
        stmt.execute();    
        } catch (Exception e){
            System.out.println("Erro ao excluir livro: " + e.getMessage());
        }
    }
    public Geral getGeral(int id){
        String sql = "SELECT * FROM geral WHERE id = ?";
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,
            ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            Geral geral = new Geral();
            rs.first();
            geral.setId(id);
            geral.setTitulo(rs.getString("titulo"));
            geral.setAutor(rs.getString("autor"));
            Sessoes categoriaid = new Sessoes();
            categoriaid.setId(rs.getInt("categoriaid"));
            geral.setCategoriaid(id);
            return geral;
        } catch(Exception e){
            return null;
            
        }
    }
    public List<Geral> getGeral(){
        String sql = "SELECT geral.id, titulo, sessoes.categoria FROM geral INNER JOIN sessoes on geral.categoriaid = sessoes.id";
                
            try{
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            List<Geral> listaGeral = new ArrayList<>();
            while(rs.next()){
                Geral geral = new Geral();
                Sessoes sessoes = new Sessoes();
                
                geral.setId(rs.getInt("id"));
                geral.setTitulo(rs.getString("titulo"));
                geral.setAutor(rs.getString("autor"));
                geral.setCategoriaid(rs.getInt("categoriaid"));
                
                
                sessoes.setCategoria(rs.getString("categoria"));
                //geral.setSessoes(sessoes);
                
                listaGeral.add(geral);
            }
            return listaGeral;
        }catch(Exception e){
            System.out.println(e.getMessage());
            return null;
        }
    }
}



